#ifdef _DEBUG
#define DebugMode true
#else
#define DebugMode false
#endif // !_DEBUG

#include "DxLib.h"
#include "resource.h"



int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {

	SetOutApplicationLogValidFlag(DebugMode);
	SetGraphMode(1280, 720, 16);
	SetDrawScreen(DX_SCREEN_BACK);
	ChangeWindowMode(TRUE);
	SetMainWindowText("DxLib");
	SetWindowIconID(IDI_ICON1);
	SetWindowSizeChangeEnableFlag(TRUE);
	if (DxLib_Init() == -1) return -1;



	DxLib_End();
	return 0;
}
